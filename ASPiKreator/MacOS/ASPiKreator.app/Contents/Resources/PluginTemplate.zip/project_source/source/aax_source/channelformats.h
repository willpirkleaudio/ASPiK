// -----------------------------------------------------------------------------
//    ASPiK AAX Shell File:  channelformats.h
//
/**
    \file   channelformats.h
    \author Will Pirkle
    \date   17-September-2018
    \brief  currently unused

        		- http://www.aspikplugins.com
	    		- http://www.willpirkle.com

*/
// -----------------------------------------------------------------------------
#ifndef VolumeAAX_I_channelformats_h
#define VolumeAAX_I_channelformats_h

// --- currently unused for AAX

#endif
