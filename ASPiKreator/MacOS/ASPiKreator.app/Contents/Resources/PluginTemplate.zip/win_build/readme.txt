Follow the CMake instructions to build your project; see the ASPiK Documentation for more information if you do not know how. 

http://aspikplugins.com/sdkdocs/html/cmake_running.html

